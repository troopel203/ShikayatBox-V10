# Deploy checklist
1. Backend (Render / HF Spaces): new Web Service from the repo, root `backend`, build `pip install -r requirements.txt`, start `uvicorn main:app --host 0.0.0.0 --port $PORT`. Copy ml/ next to it (needs ml/model.json, ml/priority_xgb.json). Add env vars from .env.example. Free tier sleeps: open /api/health before demoing.
2. Frontend (Netlify Drop / Vercel): upload this folder. Edit config.js -> window.SB_API='https://YOUR-BACKEND'. Bump `sb-v10` in sw.js so the new config is cached.
3. Email: Gmail > Security > 2-step on > App passwords > SMTP_PASS.
4. WhatsApp: developers.facebook.com > create app > WhatsApp > copy temp token + phone number ID; add up to 5 recipient numbers in the test list (test numbers can only message those).
5. SMS: Twilio trial (verified numbers only). Real India SMS needs DLT registration - not possible in a hackathon; say so.
6. Test: curl BACKEND/api/health, then file a report and change its status in the Municipal Desk.
Not connected: Bhashini (needs their keys), Supabase (data still per-browser), CLIP/MobileNet images.
