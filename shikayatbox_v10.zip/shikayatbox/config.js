// Set to your deployed backend URL, e.g. 'https://shikayatbox-api.onrender.com'. Leave '' to run fully offline/local.
window.SB_API='';
