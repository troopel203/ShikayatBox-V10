"""Drop-in replacements for the functions listed in your tweak table. Adapt names to your main.py.
Tested here: score_xgb (needs ml/priority_xgb.json). UNTESTED (need internet/HF downloads/keys): CLIP, MiniLM, Nominatim, Overpass, email."""
import time,os,smtplib,ssl,numpy as np,requests,xgboost as xgb,shap
from email.message import EmailMessage
DUP_RADIUS_M=50; IMG_CONF_MIN=0.5; TEXT_CONF_MIN=0.5; SIM_MIN=0.80
UA={"User-Agent":"ShikayatBox/1.0 (hackathon; contact: you@example.com)"}
# ---- 1. CLIP prompts (tune on ~20 real photos, then swap in fine-tuned MobileNetV2 with CLIP as fallback)
LABELS={"road":"a pothole or cracked damaged road in India","garbage":"garbage piled beside a road in India",
 "light":"a broken or unlit street light pole in India","water":"a leaking water pipe flooding a street in India",
 "drainage":"an overflowing blocked drain or open manhole in India","animal":"an injured or dead stray animal on a road in India"}
def clip_predict(img, model, proc):
    import torch
    keys=list(LABELS); inp=proc(text=list(LABELS.values()),images=img,return_tensors="pt",padding=True)
    p=model(**inp).logits_per_image.softmax(1)[0]; i=int(p.argmax()); return keys[i], float(p[i])
# ---- 2. text: MiniLM + LR trained by ml/train_text_minilm.py
_st=_lr=None
def _load():
    global _st,_lr
    if _st is None:
        from sentence_transformers import SentenceTransformer; import joblib
        _st=SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2'); _lr=joblib.load('ml/text_lr.joblib')
def text_predict(t):
    _load(); p=_lr.predict_proba(_st.encode([t]))[0]; i=int(p.argmax()); return _lr.classes_[i], float(p[i])
def text_sim(a,b):
    _load(); u,v=_st.encode([a,b]); return float(u@v/(np.linalg.norm(u)*np.linalg.norm(v)))
# ---- 3. duplicate check: PostGIS ST_DWithin(geom, point, DUP_RADIUS_M) then text_sim>=SIM_MIN
# ---- 4. review flag
def needs_review(cat,img_cat,img_conf,txt_cat,txt_conf):
    return img_conf<IMG_CONF_MIN or txt_conf<TEXT_CONF_MIN or (txt_cat!=cat) or (img_cat!=cat)
# ---- 5. APIs (no keys)
_last=0
def nominatim(lat,lng):
    global _last; time.sleep(max(0,1.05-(time.time()-_last))); _last=time.time()   # 1 req/sec policy
    a=requests.get("https://nominatim.openstreetmap.org/reverse",params=dict(format="json",lat=lat,lon=lng,zoom=17),headers=UA,timeout=8).json()
    ad=a.get("address",{}); return a.get("display_name"), ad.get("suburb") or ad.get("city_district")
def overpass(lat,lng,r=200):
    q=f'[out:json][timeout:10];nwr[amenity~"^(school|hospital|clinic)$"](around:{r},{lat},{lng});out tags 50;'
    els=requests.post("https://overpass-api.de/api/interpreter",data={"data":q},headers=UA,timeout=15).json()["elements"]
    s=sum(e["tags"].get("amenity")=="school" for e in els); return s, len(els)-s
# ---- 6. priority: XGBoost + SHAP reasons (features in ml/train_priority_xgb.py)
F=['severity','upvotes','days_open','schools_200m','hospitals_200m','repeat_reports','cat_animal','cat_drainage','cat_water','cat_road']
_m=xgb.XGBClassifier(); _m.load_model(os.path.join(os.path.dirname(__file__),'..','ml','priority_xgb.json')); _ex=shap.TreeExplainer(_m)
def score_xgb(sev,up,days,schools,hosp,repeats,cat):
    x=np.array([[sev,up,days,schools,hosp,repeats,cat=='animal',cat=='drainage',cat=='water',cat=='road']],float)
    k=int(_m.predict_proba(x)[0].argmax()); sv=_ex.shap_values(x); sv=sv[0,:,k] if sv.ndim==3 else sv[k][0]
    why=[f"{F[i]}={x[0,i]:g}" for i in np.argsort(-sv)[:3] if sv[i]>0]
    return ['Low','Medium','High','Critical'][k], why
# ---- 7. email on status change (Gmail app-password SMTP; set SMTP_USER / SMTP_PASS env vars)
def notify(to,ticket,status):
    m=EmailMessage(); m["Subject"]=f"Ticket {ticket}: {status}"; m["From"]=os.environ["SMTP_USER"]; m["To"]=to
    m.set_content(f"Your complaint {ticket} is now: {status}.")
    with smtplib.SMTP_SSL("smtp.gmail.com",465,context=ssl.create_default_context()) as s: s.login(os.environ["SMTP_USER"],os.environ["SMTP_PASS"]); s.send_message(m)
