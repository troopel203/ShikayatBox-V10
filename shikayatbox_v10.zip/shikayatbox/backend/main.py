"""ShikayatBox API. Run: uvicorn main:app --host 0.0.0.0 --port 8000   (see .env.example for keys)"""
import os,json,math,ssl,smtplib,requests
from email.message import EmailMessage
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import numpy as np
ROOT=os.path.join(os.path.dirname(__file__),'..')
app=FastAPI(title="ShikayatBox API");app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_methods=["*"],allow_headers=["*"])
# --- text category: same Naive Bayes exported to ml/model.json
M=json.load(open(os.path.join(ROOT,'ml','model.json'),encoding='utf-8'));V={w:i for i,w in enumerate(M['vocab'])};LP=np.array(M['logp']);PR=np.array(M['prior'])
def text_predict(t):
    v=np.zeros(len(V));s=' '+' '.join(t.lower().split())+' '
    for w in s.split():
        q=' '+w+' '
        for n in (2,3,4):
            for i in range(len(q)-n+1):
                j=V.get(q[i:i+n]);
                if j is not None:v[j]+=1
    sc=PR+LP@v;e=np.exp(sc-sc.max());p=e/e.sum();k=int(p.argmax());return M['classes'][k],float(p[k])
# --- priority: XGBoost + SHAP (optional if xgboost/shap installed)
try:
    import xgboost as xgb,shap
    _m=xgb.XGBClassifier();_m.load_model(os.path.join(ROOT,'ml','priority_xgb.json'));_ex=shap.TreeExplainer(_m)
except Exception:_m=None
F=['severity','upvotes','days_open','schools_200m','hospitals_200m','repeat_reports','cat_animal','cat_drainage','cat_water','cat_road']
NICE={'severity':'marked severity','upvotes':'community upvotes','days_open':'days unresolved','schools_200m':'school within 200 m','hospitals_200m':'hospital within 200 m','repeat_reports':'repeat reports','cat_animal':'animal in distress','cat_drainage':'health hazard (drainage)','cat_water':'water loss','cat_road':'road safety'}
def priority(sev,up,days,sc,ho,rp,cat):
    x=np.array([[sev,up,days,sc,ho,rp,cat=='animal',cat=='drainage',cat=='water',cat=='road']],float)
    k=int(_m.predict_proba(x)[0].argmax());sv=_ex.shap_values(x);sv=sv[0,:,k] if sv.ndim==3 else sv[k][0]
    return ['Low','Medium','High','Critical'][k],[NICE[F[i]]+f" ({x[0,i]:g})" for i in np.argsort(-sv)[:3] if sv[i]>0]
def overpass(lat,lng,r=200):
    try:
        q=f'[out:json][timeout:10];nwr[amenity~"^(school|hospital|clinic)$"](around:{r},{lat},{lng});out tags 50;'
        e=requests.post("https://overpass-api.de/api/interpreter",data={"data":q},headers={"User-Agent":"ShikayatBox/1.0"},timeout=15).json()["elements"]
        s=sum(x["tags"].get("amenity")=="school" for x in e);return s,len(e)-s
    except Exception:return 0,0
def summarize(text,cat,label,reasons):
    k=os.getenv("GROQ_API_KEY")   # optional free-tier LLM summary
    if k:
        try:
            r=requests.post("https://api.groq.com/openai/v1/chat/completions",headers={"Authorization":"Bearer "+k},timeout=15,json={"model":os.getenv("GROQ_MODEL","llama-3.1-8b-instant"),"messages":[{"role":"user","content":f"Summarize this civic complaint in one short sentence for a municipal officer. Category {cat}, priority {label}. Complaint: {text}"}]})
            return r.json()["choices"][0]["message"]["content"].strip()
        except Exception:pass
    return f"{cat.title()} · {label} priority: {text[:90]}"+(" — "+", ".join(reasons) if reasons else "")
class Report(BaseModel):
    description:str;category:str="other";lat:Optional[float]=None;lng:Optional[float]=None
    severity:int=1;upvotes:int=0;days_open:float=0;repeat_reports:int=0
@app.post("/api/analyze")
def analyze(r:Report):
    cat,conf=text_predict(r.description);sc,ho=overpass(r.lat,r.lng) if r.lat is not None else (0,0)
    label,why=priority(r.severity,r.upvotes,r.days_open,sc,ho,r.repeat_reports,r.category) if _m else ("Medium",[])
    return {"text_category":cat,"text_conf":round(conf,3),"needs_review":conf<.5 or cat!=r.category,"nearby":{"school":sc,"hospital":ho},"priority":label,"reasons":why,"summary":summarize(r.description,r.category,label,why)}
# --- notifications: email (SMTP), WhatsApp (Meta Cloud API), SMS (Twilio)
def e164(p):
    d=''.join(c for c in p if c.isdigit());return '+'+(d if len(d)>10 else '91'+d)
class Notify(BaseModel):
    ticket:str;status:str;email:Optional[str]=None;phone:Optional[str]=None
@app.post("/api/notify")
def notify(n:Notify):
    msg=f"ShikayatBox: your complaint {n.ticket} is now '{n.status}'. Track it on the portal.";out={}
    if n.email and os.getenv("SMTP_USER"):
        try:
            m=EmailMessage();m["Subject"]=f"Complaint {n.ticket}: {n.status}";m["From"]=os.environ["SMTP_USER"];m["To"]=n.email;m.set_content(msg)
            with smtplib.SMTP_SSL("smtp.gmail.com",465,context=ssl.create_default_context()) as s:s.login(os.environ["SMTP_USER"],os.environ["SMTP_PASS"]);s.send_message(m)
            out["email"]="sent"
        except Exception as e:out["email"]="failed: "+str(e)[:80]
    if n.phone and os.getenv("WA_TOKEN"):   # free test number: only pre-verified recipients, template message
        try:
            r=requests.post(f"https://graph.facebook.com/v20.0/{os.environ['WA_PHONE_ID']}/messages",headers={"Authorization":"Bearer "+os.environ["WA_TOKEN"]},timeout=15,
              json={"messaging_product":"whatsapp","to":e164(n.phone).lstrip('+'),"type":"text","text":{"body":msg}});out["whatsapp"]=r.status_code
        except Exception as e:out["whatsapp"]="failed"
    if n.phone and os.getenv("TWILIO_SID"):   # trial: only verified numbers; India needs DLT for production
        try:
            r=requests.post(f"https://api.twilio.com/2010-04-01/Accounts/{os.environ['TWILIO_SID']}/Messages.json",auth=(os.environ["TWILIO_SID"],os.environ["TWILIO_TOKEN"]),data={"From":os.environ["TWILIO_FROM"],"To":e164(n.phone),"Body":msg},timeout=15);out["sms"]=r.status_code
        except Exception as e:out["sms"]="failed"
    return out or {"skipped":"no channel configured"}
@app.get("/api/health")
def health():return {"ok":True,"xgb":_m is not None}
