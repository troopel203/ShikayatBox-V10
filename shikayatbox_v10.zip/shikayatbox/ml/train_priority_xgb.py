# XGBoost priority model on SYNTHETIC labels (rule-based + noise). SHAP gives per-report reasons.
import numpy as np,xgboost as xgb,shap
from sklearn.model_selection import train_test_split
rng=np.random.default_rng(7);N=6000
CATS=['road','garbage','drainage','light','water','animal']
F=['severity','upvotes','days_open','schools_200m','hospitals_200m','repeat_reports','cat_animal','cat_drainage','cat_water','cat_road']
c=rng.integers(0,6,N);sev=rng.integers(0,4,N);up=rng.poisson(3,N);d=rng.exponential(3,N);sc=rng.poisson(.4,N);ho=rng.poisson(.2,N);rp=rng.poisson(.8,N)
X=np.c_[sev,up,d,sc,ho,rp,c==5,c==2,c==4,c==0].astype(float)
raw=sev*12+np.minimum(up*4,28)+np.minimum(d*2,14)+sc*14+ho*16+rp*5+(c==5)*20+(c==2)*8+(c==4)*6+rng.normal(0,6,N)
y=np.digitize(raw,[20,40,60])  # 0 Low 1 Medium 2 High 3 Critical
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=1)
m=xgb.XGBClassifier(n_estimators=120,max_depth=4,learning_rate=.1,objective='multi:softprob').fit(Xtr,ytr)
print("held-out accuracy (synthetic labels):",round(m.score(Xte,yte),3))
m.save_model("priority_xgb.json")
ex=shap.TreeExplainer(m)
def explain(x,top=3):
    p=m.predict_proba([x])[0];k=int(p.argmax());sv=ex.shap_values(np.array([x]))
    sv=sv[0,:,k] if getattr(sv,'ndim',0)==3 else sv[k][0]
    idx=np.argsort(-sv)[:top];return ['Low','Medium','High','Critical'][k],[f"{F[i]}={x[i]:g} ({sv[i]:+.2f})" for i in idx if sv[i]>0]
print(explain([2,8,5,1,1,3,1,0,0,0]))
