# Multilingual MiniLM embeddings + LogisticRegression. Run in Colab/locally (needs HF download; UNTESTED here).
# pip install sentence-transformers scikit-learn joblib
import joblib,sys;sys.path.insert(0,'.')
from sentence_transformers import SentenceTransformer
from sklearn.linear_model import LogisticRegression
import importlib.util,re
src=open('train_text_model.py',encoding='utf-8').read().split("Xtr,Xte")[0]  # reuse the synthetic seeds (S, P, X, y)
ns={};exec(src,ns);X,y=ns['X'],ns['y']
st=SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')
clf=LogisticRegression(max_iter=2000,C=4).fit(st.encode(X,batch_size=64,show_progress_bar=True),y)
joblib.dump(clf,'text_lr.joblib');print('saved text_lr.joblib')
